//
//  PostDeckCompletionView.swift
//  FlashFantasy
//
//  Created by Kevin Nguyen on 4/24/25.
//


import SwiftUI

struct StudyFinishView: View {
    var onFinish: () -> Void
    @State private var showTetris: Bool = false
    @State private var showFlappy: Bool = false
    @State private var showButton: Bool = true
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]),
                               startPoint: .top,
                               endPoint: .bottom)
                .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Text("Great job!")
                        //.forgroundColor(Color.white)
                        .font(.custom("Papyrus", size: 35))
                        .foregroundColor(Color.white)
                        .bold()
                        .padding(.top)
                    
                    Text("What would you like to do next?")
                        .font(.custom("Papyrus", size: 20))
                        .foregroundColor(Color.white)
                    
                    Button("Play Tetris") {
                        showTetris = true
                        showButton = false
                    }
                    
                    .padding()
                    .background(Color.white)
                    .foregroundColor(.purple)
                    .cornerRadius(10)
                    .disabled(!showButton)
                    .opacity(showButton ? 1.0 : 0.5)
                    
                    Button("Play Flappy Bird") {
                        showFlappy = true
                        showButton = false
                    }
                    .padding()
                    .background(Color.white)
                    .foregroundColor(.purple)
                    .cornerRadius(10)
                    .disabled(!showButton)
                    .opacity(showButton ? 1.0 : 0.5)
                    
                    Button("Go Back") {
                        onFinish()
                        showButton = true
                    }
                    .padding()
                    .background(Color.white)
                    .foregroundColor(.blue)
                    .cornerRadius(10)
                    .disabled(!showButton)
                    .opacity(showButton ? 1.0 : 0.5)
                }
                .padding()
            }
            // Navigate to games
            .navigationDestination(isPresented: $showTetris) {
                TetrisView(navigateToTetris: $showTetris)
            }

            .navigationDestination(isPresented: $showFlappy) {
                FlappyBirdWrapper()
            }
        }
    }
}

